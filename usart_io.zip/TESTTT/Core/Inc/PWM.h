#ifndef PWM_PWM_H_
#define PWM_PWM_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "main.h"
#include "stm32f1xx_hal_tim.h"
TIM_HandleTypeDef hitm;
void PWM_Init(void);
void Vehi_GO(void);
void Vehi_Top(void);
void Vehi_Ret(void);

#ifdef __cplusplus
}
#endif
#endif /* PWM_PWM_H_ */