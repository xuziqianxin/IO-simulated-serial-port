#include "PWM.h"

extern HAL_StatusTypeDef HAL_TIM_PWM_Init(TIM_HandleTypeDef *htim);

void PWM_Init(void)
{
	hitm.Instance = TIM4;
	hitm.Init.Prescaler=(uint32_t)((SystemCoreClock / 2) / 1000000) - 1;
	hitm.Init.CounterMode = TIM_COUNTERMODE_UP;
	hitm.Init.Period = 1000 - 1;
	hitm.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	hitm.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
	HAL_TIM_PWM_Init(&hitm);

	TIM_OC_InitTypeDef PWMfig= {0};

	PWMfig.OCMode = TIM_OCMODE_PWM1;
	PWMfig.Pulse = 500;
	PWMfig.OCPolarity = TIM_OCPOLARITY_HIGH;
	PWMfig.OCFastMode = TIM_OCFAST_DISABLE;
	HAL_TIM_PWM_ConfigChannel(&hitm, &PWMfig, TIM_CHANNEL_4);
//	  HAL_TIM_PWM_ConfigChannel(&hitm, &PWMfig, TIM_CHANNEL_3);

}
